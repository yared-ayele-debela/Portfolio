<x-app-layout>
    <x-slot name="header">
    
    </x-slot>

    <button>
    </button>
   
</x-app-layout>
