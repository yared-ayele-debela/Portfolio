
<?php $__env->startSection('dashboard'); ?>
<div class="pagetitle pt-4">
  <nav>
     <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item">Services</li>
     </ol>
  </nav>
</div>
<section class="section">
  <div class="row">
     <div class="col-lg-12">
        <div class="card">
           <div class="card-body">
              <h5 class="card-title">All Services</h5>
              <ul class="nav nav-tabs pb-4 align-items-end card-header-tabs w-100">
               <li class="nav-item">
                 <a class="nav-link active" href="<?php echo e(route('allservice')); ?>"><i class="fa fa-list mr-2"></i>All Services</a>
               </li>
                 <li class="nav-item border-none">
                 <a class="nav-link bg-light" href="<?php echo e(route('create_service')); ?>"><i class=" fas fa-plus"></i>Add Service</a>
               </li>
              </ul>
              <table class="table datatable">
                 <thead>
                    <tr>
                       <th scope="col">Id</th>
                       <th scope="col">Name</th>
                       <th scope="col">Technology </th>
                       <th scope="col">price</th>
                       <th scope="col">Status</th>
                       <th scope="col">Action</th>
                    </tr>
                 </thead>
                 <tbody>
                  <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <tr>
                       <td><?php echo e($service->id); ?></td>
                       <td><?php echo e($service->service_name); ?></td>
                       <td><?php echo e($service->technology_used); ?></td>
                       <td><?php echo e($service->price); ?></td>

                       <td>
                     <?php if($service->status==0): ?>
                     <a href="<?php echo e(url('service/active/'.$service->id)); ?>"><span style="border-radius: 0.2rem;padding-left:3px;padding-right:3px"  class=" bg-danger text-white    active-btn">Inactive</span></a>
                     <?php elseif($service->status==1): ?>
                     <a href="<?php echo e(url('service/inactive/'.$service->id)); ?>"><span style="border-radius: 0.2rem;padding-left:5px;padding-right:5px" class=" bg-success text-white  active-btn">Active</span></a>                        
                     <?php endif; ?>
                      </td>
                       <td>
                        <a href="<?php echo e(url('service/services/'.$service->id)); ?>"  style="background-color:rgb(239, 239, 239) "  class="btn btn-sm"><i class="ri-ball-pen-fill"></i></a>
                        <a href="<?php echo e(url('service/'.$service->id)); ?>"  style="background-color:rgb(239, 239, 239) "  class="btn  btn-sm" id="delete"><i class=" ri-delete-bin-6-fill"></i></a>
                       </td>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
              </table>
     
           </div>
        </div>
     </div>
  </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layouts.maindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Laravel_Projects\Portfolio\resources\views/service/allservices.blade.php ENDPATH**/ ?>