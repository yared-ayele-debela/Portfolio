
<?php $__env->startSection('dashboard'); ?>
  <div class="pagetitle">
     <nav>
        <ol class="breadcrumb">
           <li class="breadcrumb-item"><a href="index.html">Home</a></li>
           <li class="breadcrumb-item">Update Service</li>
        </ol>
     </nav>
  </div>
  <section class="section">
     <div class="row">
        <div class="col-lg-8">
           <div class="card">
              <div class="card-body">
                 <h5 class="card-title">Service </h5>
                 <ul class="nav pb-5 nav-tabs align-items-end card-header-tabs w-100">
                  <li class="nav-item">
                    <a class="nav-link active" href"><i class="fa fa-list mr-2"></i>Update Services</a>
                  </li>
                    <li class="nav-item border-none">
                    <a class="nav-link bg-light " href="<?php echo e(route('service')); ?>"><i class=" fas fa-plus"></i>All Services</a>
                  </li>
                 </ul>
                 <form method="POST" action="<?php echo e(route('allservice')); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                    <div class="row mb-3">
                       <label for="service_name" class="col-sm-2 col-form-label">Service Name</label>
                       <div class="col-sm-10"> 
                        <input type="text" name="service_name" value="<?php echo e($service->service_name); ?>" class="form-control">
                        <?php $__errorArgs = ['service_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class=" text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                    </div>
                    <div class="row mb-3">
                       <label for="price" class="col-sm-2 col-form-label">Price</label>
                       <div class="col-sm-10"> 
                        <input type="number" value="<?php echo e($service->price); ?>" name="price" class="form-control">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class=" text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                    </div>
                     <div class="row mb-3">
                        <label for="technology_used" class="col-sm-2 col-form-label">Techology</label>
                        <div class="col-sm-10"> 
                         <input type="text" value="<?php echo e($service->technology_used); ?>" name="technology_used" class="form-control">
                         <?php $__errorArgs = ['technology_used'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <small class=" text-danger"><?php echo e($message); ?></small>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                     <div class="row mb-3">
                        <label for="service_description" class="col-sm-2 col-form-label">Description</label>
                        <div class="col-sm-10 "> 
                        <textarea class="form-control" name="service_description" id="" cols="40" rows="10"><?php echo e($service->service_description); ?></textarea>
                        <?php $__errorArgs = ['service_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class=" text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      
                     </div>
                    <div class="row mb-3">
                     <label class="col-sm-2 col-form-label"></label>
                        <div class="col-sm-10 ">
                         <button type="submit" class="btn btn-primary">Save Service</button>
                        </div>
                    </div>
                 </form>
              </div>
           </div>
        </div>
     </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.maindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Laravel_Projects\Portfolio\resources\views/service/editservice.blade.php ENDPATH**/ ?>