
<?php $__env->startSection('dashboard'); ?>
<div class="pagetitle pt-4">
  <nav>
     <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item">categories</li>
     </ol>
  </nav>
</div>
<section class="section">
  <div class="row">
     <div class="col-lg-12">
        <div class="card">
           <div class="card-body">
              <h5 class="card-title">All category Data</h5>
              <ul class="nav nav-tabs pb-4 align-items-end card-header-tabs w-100">
               <li class="nav-item">
                 <a class="nav-link active" href"><i class="fa fa-list mr-2"></i>All category</a>
               </li>
                 <li class="nav-item border-none">
                 <a class="nav-link bg-light" href="<?php echo e(route('create_category')); ?>"><i class=" fas fa-plus"></i>Add User</a>
               </li>
              </ul>
              <table class="table datatable">
                 <thead>
                    <tr>
                       <th scope="col">Id</th>
                       <th scope="col">Name</th>
                       <th scope="col">Description</th>
                       <th scope="col">status</th>
                       <th scope="col">Action</th>
                    </tr>
                 </thead>
                 <tbody>
                  <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <tr>
                       <td><?php echo e($category->id); ?></td>
                       <td><?php echo e($category->name); ?></td>
                       <td><?php echo e($category->description); ?></td>
                       <td>
                     <?php if($category->status==0): ?>
                     <a href="<?php echo e(url('category/active/'.$category->id)); ?>"><span style="border-radius: 0.2rem;padding-left:3px;padding-right:3px"  class=" bg-danger text-white    active-btn">Inactive</span></a>
                     <?php elseif($category->status==1): ?>
                     <a href="<?php echo e(url('category/inactive/'.$category->id)); ?>"><span style="border-radius: 0.2rem;padding-left:5px;padding-right:5px" class=" bg-success text-white  active-btn">Active</span></a>                        
                     <?php endif; ?>
                      </td>
                       <td>
                        <a href="<?php echo e(url('category/categories/'.$category->id)); ?>"  style="background-color:rgb(239, 239, 239) "  class="btn btn-sm"><i class="ri-ball-pen-fill"></i></a>
                        <a href="<?php echo e(url('category/'.$category->id)); ?>"  style="background-color:rgb(239, 239, 239) "  class="btn  btn-sm" id="delete"><i class=" ri-delete-bin-6-fill"></i></a>
                       </td>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
              </table>
     
           </div>
        </div>
     </div>
  </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layouts.maindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Laravel_Projects\Portfolio\resources\views/category/allcategories.blade.php ENDPATH**/ ?>