<footer id="footer" class="footer">
  <div class="copyright"> © Copyright <strong><span>Compnay Name</span></strong>. All Rights Reserved</div>
  <div class="credits"> with love <a href="https://freeetemplates.com/">FreeeTemplates</a></div>
</footer><?php /**PATH C:\Users\yared\Laravel_Projects\Portfolio\resources\views/admin_layouts/footer.blade.php ENDPATH**/ ?>