
<?php $__env->startSection('dashboard'); ?>
<div class="pagetitle">
  <h1>Data Tables</h1>
  <nav>
     <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item">Users</li>
        <li class="breadcrumb-item active">Users Data</li>
     </ol>
  </nav>
</div>
<section class="section">
  <div class="row">
     <div class="col-lg-12">
        <div class="card">
           <div class="card-body">
              <h5 class="card-title">All Users Data</h5>
              <ul class="nav nav-tabs pb-4 align-items-end card-header-tabs w-100">
               <li class="nav-item">
                 <a class="nav-link active" href"><i class="fa fa-list mr-2"></i>All Users</a>
               </li>
                 <li class="nav-item border-none">
                 <a class="nav-link bg-light" href="<?php echo e(route('addUser')); ?>"><i class=" fas fa-plus"></i>Add User</a>
               </li>
              </ul>
              <table class="table datatable">
                 <thead>
                    <tr>
                       <th scope="col">Num</th>
                       <th scope="col">Name</th>
                       <th scope="col">Email</th>
                       <th scope="col">User Type</th>
                       <th scope="col">Status</th>
                    </tr>
                 </thead>
                 <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <tr>
                       <td><?php echo e($k++); ?></td>
                       <td><?php echo e($users->name); ?></td>
                       <td><?php echo e($users->email); ?></td>
                       <td>
                        <?php if($users->usertype=='Admin'): ?>
                           <a href=""><span style="border-radius: 0.2rem" class=" bg-success text-white pl-2 pr-2   active-btn"><?php echo e($users->usertype); ?></span></a>
                            <?php elseif($users->usertype=='Super Admin'): ?>
                           <a href=""><span style="border-radius: 0.2rem; padding-left:3px;padding-right:3px" class=" bg-warning text-white pl-4 pr-4   active-btn"><?php echo e($users->usertype); ?></span></a>
                            <?php elseif($users->usertype=='User'): ?>
                           <a href=""><span style="border-radius: 0.2rem; padding-left:3px; padding-right:3px;" class=" bg-primary text-white pl-2 pr-2   active-btn"><?php echo e($users->usertype); ?></span></a>
                        <?php endif; ?>
                       </td>
                       <td>
                     <?php if($users->status==0): ?>
                     <a href="<?php echo e(url('active/'.$users->id)); ?>"><span style="border-radius: 0.2rem;padding-left:3px;padding-right:3px"  class=" bg-danger text-white    active-btn">Inactive</span></a>
                     <?php elseif($users->status==1): ?>
                     <a href="<?php echo e(url('inactive/'.$users->id)); ?>"><span style="border-radius: 0.2rem;padding-left:5px;padding-right:5px" class=" bg-success text-white  active-btn">Active</span></a>                        
                     <?php endif; ?>
                      </td>
                       <td>
                        <a href="<?php echo e(url('user/'.$users->id.'/edit')); ?>" class=" btn btn-warning btn-sm">Edit</a>
                        <a href="<?php echo e(url('user/'.$users->id)); ?>" class="btn btn-danger btn-sm" id="delete">Delete</a>
                       </td>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
              </table>
     
           </div>
        </div>
     </div>
  </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layouts.maindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Laravel_Projects\Portfolio\resources\views/User/allluser.blade.php ENDPATH**/ ?>