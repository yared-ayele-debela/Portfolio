
<?php $__env->startSection('content'); ?>

<div class="content-wrapper" style="min-height: 1345.6px;">

      <a href="<?php echo e(route('addUser')); ?>">ADd</a>
    <form action="<?php echo e(url('storeadmin')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="name">Name</label><br>
    <input type="text" name="name" id=""><br>
    <label for="phone">Phone</label>
    <input type="number" name="phone">
    <input type="submit" class="btn btn-success bg-primary" value="Add User">
</div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.maindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Laravel_Projects\UserManagements_with_jetstream\resources\views/User/addadmin.blade.php ENDPATH**/ ?>