
<footer class="footer text-center py-4">
    <small class="copyright">Yared Ayele Copyright &copy; <a href="https://themes.3rdwavemedia.com/" target="_blank">3rd Wave Media</a></small>
</footer><?php /**PATH C:\Users\yared\Laravel_Projects\Portfolio\resources\views/fontend/footer.blade.php ENDPATH**/ ?>